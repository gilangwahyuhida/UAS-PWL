<!DOCTYPE html>
<html>
<head>
<title><?php echo $title;?></title>
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>
</head>
<body>
<label><h2><b>Laundry Sepatu</b></h2></label>
<table>
  <tr>
    <th>ID</th>
    <th>Nama</th>
    <th>Alamat</th>
    <th>Merk</th>   
	<th>Ukuran</th>
	<th>Warna</th>
	<th>Jumlah</th>
	<th>Tujuan</th>
	<th>Total</th>   
  </tr>
  <?php 
  $no=1; 
  foreach($customers as $cs){ 
  <tr>
  <td><?php echo $id ?></td>
  <td><?php echo $row->nama;?></td>
  <td><?php echo $row->alamat;?></td>
  <td><?php echo $row->merk;?></td>
  <td><?php echo $row->ukuran;?></td>
  <td><?php echo $row->warna;?></td>
  <td><?php echo $row->jumlah;?></td>
  <td><?php echo $row->tujuan;?></td>
  <td><?php echo $row->total;?></td>
  </tr>
  endforeach;
} ?>
  
    
</table>

</body>
</html>
