<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class modlaund extends CI_Model{
    public function getTable(){

        $this->db->select('customer.*, sepatu');
        $this->db->from('customer');
        $this->db->join('sepatu','sepatu.id_spt=customer.id_spt');
        $this->db->join('delivery','delivery.id_deliv=sepatu.id_deliv');
        $this->db->where($aktif);
        $query = $this->db->get();
        return $query->result();
    }
}