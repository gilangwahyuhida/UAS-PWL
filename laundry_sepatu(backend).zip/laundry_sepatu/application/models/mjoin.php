<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Mjoin extends CI_Model {

    public function tigatable($aktif){
        $this->db->select('*');
        $this->db->from('customer');
        $this->db->join('sepatu','sepatu.id_spt=customer.id_spt');
        $this->db->join('delivery','delivery.id_deliv=sepatu.id_deliv');
        $this->db->where($aktif);
        $query = $this->db->get();
        return $query->result();
    }

    public function tampil_data(){
        return $this->db->get('customer');
    }
}