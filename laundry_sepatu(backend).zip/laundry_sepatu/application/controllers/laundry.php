<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class laundry extends CI_Controller{

    function__construct(){

        parent::__construct();
        $this->load->model('modlaund', '', TRUE);
        $this->load->helper(array('form','url'));
    }

    public function index(){
        
        $data['title'] = "Laundry Sepatu";
        $aktif = array('nama'=>'Agus');
        $data['join3'] = $this->mjoin->tigatable($aktif);
        $this->load->view('nong',$data);
    }
}