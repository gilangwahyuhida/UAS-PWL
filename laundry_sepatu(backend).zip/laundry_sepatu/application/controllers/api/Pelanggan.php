<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Pelanggan extends REST_Controller{

    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Mod_pelanggan','pelanggan');
        
    }

    public function index_get(){
        $id = $this->get('id');
        if ($id == null ) {
            $pelanggan = $this->pelanggan->getpelanggan();
        
        }else {
            $pelanggan = $this->pelanggan->getpelangganbyid($id);
            
        }

        if ($pelanggan) {
            $this->response([
                'status ' => true,
                'data' => $pelanggan
            ],REST_Controller::HTTP_OK);
        }else {
            $this->response([
                'status' => false,
                'message' => 'pelanggan tidak ditemukan'
            ],REST_Controller::HTTP_NOT_FOUND);
        }
    }
    
    public function index_post() {
        $data = [

               'nama_pelanggan' => $this->post('nama_pelanggan'),
                'no_hp' => $this->post('no_hp')
        ];

        $this->db->insert("pelanggan", $data);

        $this->set_response($data, REST_Controller::HTTP_CREATED); // CREATED (201) being the HTTP response code
    }

    
    public function index_delete() {
        $id= $this->delete('id_pelanggan');

        if($id === null) {
            $this->response([
                'status' => false,
                'message' => 'provide an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }else{
            if($this->pelanggan->hapusPelanggan($id) > 0) {
                //ok
                $this->response([
                    'status' => true,
                    'id_pelanggan' => $id,
                    'message' => 'deleted.'
                ], REST_Controller::HTTP_OK);
            }else {
                // id not found
                $this->response([
                    'status' => false,
                    'message' => 'id not found!'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }
    
    

}