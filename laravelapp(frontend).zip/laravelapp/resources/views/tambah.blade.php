@extends('base')
<!-- isi title -->
@section('title','Tambah Data')

<!-- isi judul halaman -->
@section('judul_halaman', 'Tambah Data Pelanggan')

<!-- isi bagian konten -->
@section('konten')
    <a href="/pelanggan" class="btn btn-danger">Kembali</a>
    <br/>
    <br/>
    <!-- menampilkan form validasi -->
        @if (count($errors) > 0)
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
        <!-- form validasi -->
        <form action="/pelanggan/simpan" method="post">
            {{ csrf_field() }}

            <div class="form-group">
                <label for="nama">Nama</label>
                <input class="form-control" type="text" name="nama_pelanggan" value="{{ old('nama_pelanggan') }}"> 
            </div>

            <div class="form-group">
                <label for="nama">Nomor Handphone</label>
                <input class="form-control" type="text" name="no_hp" value="{{ old('no_hp') }}"> 
            </div>


            <div class="form-group">
                <input class="btn btn-primary" type="submit" value="Tambah">
            </div>
        </form>
@endsection