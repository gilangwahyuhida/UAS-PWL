@extends('base')
@section('content')
    <!-- Main Section -->
    <section class="main-section">
    
    </section>
    <!-- /.main-section -->
@endsection