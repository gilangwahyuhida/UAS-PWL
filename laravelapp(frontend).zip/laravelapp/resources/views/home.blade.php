@extends('base') {{-- mengambil file base.blade.php --}}
@section('content') {{-- Mengisi di bagian content --}}
@section('title', 'Home')
    <!-- Main Section -->
    <section class="main-section">
        <!-- Add Your Content Inside -->
        <div class="content">
            <!-- Remove This Before You Start -->
            <h2>Selamat Datang Di Shoestress</h2>

            <a href="/logout" class="btn btn-primary btn-lg">Logout</a>
        </div>
        <!-- /.content -->
    </section>
    <!-- /.main-section -->
    
@endsection