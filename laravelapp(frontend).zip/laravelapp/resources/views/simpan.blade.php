@extends('base')

<!-- isi Title -->
@section('title', 'Validasi Data')

<!-- isi bagian judul halaman  -->
@section('judul_halaman', 'Validasi Data Pelanggan')

<!-- isi bagian konten -->
@section('konten')
<h3 class="my-4">Data Yang Di Input : </h3>

    <table class="table table-bordered table-striped">
        <tr>
            <td style="width:150px">Nama</td>
            <td>{{ $data['nama_pelanggan'] }}</td>
        </tr>

        <tr>
            <td>Nomor Handphone</td>
            <td>{{ $data ['no_hp'] }}</td>
        </tr>

        <!-- <tr>
            <td>E-mail</td>
            <td>{{ $data->email}}</td>
        </tr>

        <tr>
            <td>Jurusan</td>
            <td>{{ $data->jurusan}}</td>
        </tr> -->
    </table>

    <a href="/pelanggan" class="btn btn-primary">Kembali</a>
@endsection