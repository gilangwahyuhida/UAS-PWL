@extends('base') {{-- mengambil file base.blade.php --}}
@section('content') {{-- Mengisi di bagian content --}}
@section('title', 'Home')
<!DOCTYPE html>
<html>
    <head>
        <title>About</title>
    </head>
    <body>
        <h4>POLITEKNIK NEGERI MALANG</h4>
        Nama Tugas : {{ $tampil['judul'] }} <br/>
        Dibuat Oleh : {{ $tampil ['pembuat'] }} <br/>
        Kelas : {{ $tampil ['kelas'] }}
    </body>
</html>
@endsection