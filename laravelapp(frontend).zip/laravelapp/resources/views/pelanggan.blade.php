@extends('base') {{-- mengambil file base.blade.php --}}
@section('content') {{-- Mengisi di bagian content --}}
@section('title', 'Data Pelanggan')
    <!-- Main Section -->
    <section class="main-section">
        <!-- Add Your Content Inside -->
        <div class="content">
            <!-- Remove This Before You Start -->
            <h2>Selamat Datang Di Shoestress</h2>

            <a href="/logout" class="btn btn-primary btn-lg">Logout</a>
        </div>
        <!-- /.content -->
    </section>
    <!-- /.main-section -->
    <a href="/pelanggan/tambah" class="btn btn-primary">Tambah Data Pelanggan</a>
    <br/>
    <br/>
    <table class="table table-bordered table-hover table-striped">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Nomor Handphone</th>
            </tr>
        </thead>
        <tbody>
            @foreach($pelanggan as $data)
            <tr>
            <td>{{ $data ['nama_pelanggan'] }} </td>
            <td> {{ $data['no_hp'] }}</td>
                <td>
                <a href="/pelanggan/detail/{{$data ['id_pelanggan'] }}" class="badge badge-warning">Detail</a>
                <a href="/pelanggan/edit/{{$data ['id_pelanggan'] }}" class="badge badge-warning">Edit</a>
                <a href="/pelanggan/hapus/{{$data ['id_pelanggan'] }}" class="badge badge-danger">Hapus</a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
@endsection