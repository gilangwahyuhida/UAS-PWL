@extends('base')

<!-- Isi Title -->
@section('title', 'Detail Pelanggan')

<!-- Isi Bagian Judul Halaman -->
@section('judul_halaman', 'Detail Data Pelanggan')

<!-- Isi Bagian Konten -->
@section('konten')
<a href="/pelanggan" class="btn btn-danger">Kembali</a>
<br>
<br>

@foreach($pelanggan as $data)
<h5 class="card-title">{{ $data['nama_pelanggan'] }}</h5>
<p class="card-text">
    <label for=""><b>Nama : </b></label>
    {{ $data ['nama_pelanggan'] }}
</p>
<p class="card-text">
    <label for=""><b>Nomer Handphone : </b></label>
    {{ $data  ['no_hp'] }}
</p>
@endforeach
@endsection