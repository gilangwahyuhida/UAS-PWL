 
<?php $__env->startSection('content'); ?> 
<?php $__env->startSection('title', 'Home'); ?>
<!DOCTYPE html>
<html>
    <head>
        <title>About</title>
    </head>
    <body>
        <h4>POLITEKNIK NEGERI MALANG</h4>
        Nama Tugas : <?php echo e($tampil['judul']); ?> <br/>
        Dibuat Oleh : <?php echo e($tampil ['pembuat']); ?> <br/>
        Kelas : <?php echo e($tampil ['kelas']); ?>

    </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\client\laravelapp\resources\views/about.blade.php ENDPATH**/ ?>