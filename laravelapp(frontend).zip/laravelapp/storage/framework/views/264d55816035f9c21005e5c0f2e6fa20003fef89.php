
<?php $__env->startSection('content'); ?>
    <!-- Main Section -->
    <section class="main-section">
        <!-- Add Your Content Inside -->
        <div class="content">
            <!-- Remove This Before You Start -->
            <h1>Login Account</h1>
            <hr>
            <?php if(\Session::has('alert')): ?>
                <div class="alert alert-danger">
                    <div><?php echo e(Session::get('alert')); ?></div>
                </div>
            <?php endif; ?>
            <?php if(\Session::has('alert-success')): ?>
                <div class="alert alert-success">
                    <div><?php echo e(Session::get('alert-success')); ?></div>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(url('/loginPost')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="alamat">Password:</label>
                    <input type="password" class="form-control" id="password" name="password"></input>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-md btn-primary">Login</button>
                    <a href="<?php echo e(url('register')); ?>" class="btn btn-md btn-warning">Register</a>
                </div>
            </form>
        </div>
        <!-- /.content -->
    </section>
    <!-- /.main-section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\client\laravelapp\resources\views/login.blade.php ENDPATH**/ ?>