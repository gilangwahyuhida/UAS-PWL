
<!-- isi title -->
<?php $__env->startSection('title','Tambah Data'); ?>

<!-- isi judul halaman -->
<?php $__env->startSection('judul_halaman', 'Tambah Data Pelanggan'); ?>

<!-- isi bagian konten -->
<?php $__env->startSection('konten'); ?>
    <a href="/pelanggan" class="btn btn-danger">Kembali</a>
    <br/>
    <br/>
    <!-- menampilkan form validasi -->
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <!-- form validasi -->
        <form action="/pelanggan/simpan" method="post">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <label for="nama">Nama</label>
                <input class="form-control" type="text" name="nama_pelanggan" value="<?php echo e(old('nama_pelanggan')); ?>"> 
            </div>

            <div class="form-group">
                <label for="nama">Nomor Handphone</label>
                <input class="form-control" type="text" name="no_hp" value="<?php echo e(old('no_hp')); ?>"> 
            </div>


            <div class="form-group">
                <input class="btn btn-primary" type="submit" value="Tambah">
            </div>
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\client\laravelapp\resources\views/tambah.blade.php ENDPATH**/ ?>