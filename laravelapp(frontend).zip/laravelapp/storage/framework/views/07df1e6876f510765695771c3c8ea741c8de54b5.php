

<!-- isi Title -->
<?php $__env->startSection('title', 'Validasi Data'); ?>

<!-- isi bagian judul halaman  -->
<?php $__env->startSection('judul_halaman', 'Validasi Data Pelanggan'); ?>

<!-- isi bagian konten -->
<?php $__env->startSection('konten'); ?>
<h3 class="my-4">Data Yang Di Input : </h3>

    <table class="table table-bordered table-striped">
        <tr>
            <td style="width:150px">Nama</td>
            <td><?php echo e($data['nama_pelanggan']); ?></td>
        </tr>

        <tr>
            <td>Nomor Handphone</td>
            <td><?php echo e($data ['no_hp']); ?></td>
        </tr>

        <!-- <tr>
            <td>E-mail</td>
            <td><?php echo e($data->email); ?></td>
        </tr>

        <tr>
            <td>Jurusan</td>
            <td><?php echo e($data->jurusan); ?></td>
        </tr> -->
    </table>

    <a href="/pelanggan" class="btn btn-primary">Kembali</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\client\laravelapp\resources\views/simpan.blade.php ENDPATH**/ ?>