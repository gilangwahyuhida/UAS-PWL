 
<?php $__env->startSection('content'); ?> 
<?php $__env->startSection('title', 'Data Pelanggan'); ?>
    <!-- Main Section -->
    <section class="main-section">
        <!-- Add Your Content Inside -->
        <div class="content">
            <!-- Remove This Before You Start -->
            <h2>Selamat Datang Di Shoestress</h2>

            <a href="/logout" class="btn btn-primary btn-lg">Logout</a>
        </div>
        <!-- /.content -->
    </section>
    <!-- /.main-section -->
    <a href="/pelanggan/tambah" class="btn btn-primary">Tambah Data Transaksi</a>
    <!-- <a href="/pelanggan/tambah" class="btn btn-primary">Tambah Data Pelanggan</a> -->
    <br/>
    <br/>
    <table class="table table-bordered table-hover table-striped">
        <thead>
            <tr>
                
                <!-- <th>Nama Pelanggan</th> -->

                <th>Nama Pelanggan</th>
                <th>Nomor Telefon</th>
                <th>Tanggal Masuk</th>
                <th>Tanggal Selesai</th>
                <th>Status</th>
                
             
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td> <?php echo e($data ['nama_pelanggan']); ?> </td>
            <td> <?php echo e($data ['no_hp']); ?> </td>
            <td> <?php echo e($data ['tgl_masuk']); ?> </td>
            <td> <?php echo e($data['tgl_selesai']); ?></td>
            <td> <?php echo e($data['status']); ?></td>
            
                <td>
                <!-- <a href="/pelanggan/detail/<?php echo e($data['id_transaksi']); ?>" class="badge badge-warning">Detail</a> -->
                <!-- <a href="/pelanggan/edit/<?php echo e($data ['id_transaksi']); ?>" class="badge badge-warning">Edit</a> -->
                <!-- <a href="/pelanggan/hapus/<?php echo e($data ['id_transaksi']); ?>" class="badge badge-danger">Hapus</a> -->
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\client\laravelapp\resources\views/transaksi.blade.php ENDPATH**/ ?>