

<!-- Isi Title -->
<?php $__env->startSection('title', 'Detail Pelanggan'); ?>

<!-- Isi Bagian Judul Halaman -->
<?php $__env->startSection('judul_halaman', 'Detail Data Pelanggan'); ?>

<!-- Isi Bagian Konten -->
<?php $__env->startSection('konten'); ?>
<a href="/pelanggan" class="btn btn-danger">Kembali</a>
<br>
<br>

<?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h5 class="card-title"><?php echo e($data['nama_pelanggan']); ?></h5>
<p class="card-text">
    <label for=""><b>Nama : </b></label>
    <?php echo e($data ['nama_pelanggan']); ?>

</p>
<p class="card-text">
    <label for=""><b>Nomer Handphone : </b></label>
    <?php echo e($data  ['no_hp']); ?>

</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\client\laravelapp\resources\views/detail.blade.php ENDPATH**/ ?>