
<?php $__env->startSection('content'); ?>
    <!-- Main Section -->
    <section class="main-section">
    
    </section>
    <!-- /.main-section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\client\laravelapp\resources\views/index.blade.php ENDPATH**/ ?>