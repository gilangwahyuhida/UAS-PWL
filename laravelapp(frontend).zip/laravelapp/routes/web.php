<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
    //return view('welcome');
//});
Route::get('/about', 'AboutController@index');

Route::get('/', function () {
    return view('login');
});
Route::get('/home', function () {
    return view('home');
});
Route::get('/home_user', 'User@index');
Route::get('/login', 'User@login');
Route::post('/loginPost', 'User@loginPost');
Route::get('/register', 'User@register');
Route::post('/registerPost', 'User@registerPost');
Route::get('/logout', 'User@logout');

Route::get('/pelanggan', 'PelangganController@GetPelanggan');

Route::get('/pelanggan/tambah','PelangganController@tambah');

Route::post('/pelanggan/simpan','PelangganController@simpan');

Route::get('/transaksi', 'PelangganController@GetTransaksi');

Route::get('/pelanggan/detail/{id_pelanggan}', 'PelangganController@detail');

Route::get('/pelanggan/hapus/{id_pelanggan}', 'PelangganController@hapus');