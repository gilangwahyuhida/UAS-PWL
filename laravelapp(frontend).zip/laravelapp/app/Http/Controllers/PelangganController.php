<?php

namespace App\Http\Controllers;

use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Http\Controllers\Controller;
use App\User;
use DB;



class PelangganController extends Controller
{
    public function GetPelanggan(){
        
        $response = Http::get('http://localhost/rest-api/laundry_sepatu/api/pelanggan');
        // dd($response->body());
        $result = json_decode($response->getBody()->getContents(), true);
        return view('pelanggan', ['pelanggan' => $result['data']]);

        
    }

    public function GetTransaksi(){
        
        $response = Http::get('http://localhost/rest-api/laundry_sepatu/api/transaksi');
        // dd($response->body());
        $result = json_decode($response->getBody()->getContents(), true);
        return view('transaksi', ['transaksi' => $result['data']]);
    }
    public function tambah(){

        // $response = Http::post('http://localhost/rest-api/laundry_sepatu/api/pelanggan',[
        //     'Nama Pelanggan' => 'nama_pelanggan',
        //     'Nomor Handphone' => 'no_hp'
        // ]);
        // $result = json_decode($response->getBody()->getContents(), true);
        // return view('tambah', ['pelanggan' => $result['data']]);

        //memanggil view tambah
        return view('tambah');
    }

    public function simpan(){

        $response = Http::post('http://localhost/rest-api/laundry_sepatu/api/pelanggan',[
                'nama_pelanggan' =>nama_pelanggan,
                'no_hp' =>  no_hp 
        ]);
        $result = json_decode($response->getBody()->getContents(), true);
        return view('simpan', ['pelanggan' => $result['data']]);
        // return view('simpan',['data' => $request]);

    }

    public function detail($id_pelanggan){

        $client = new Client();

        $response = $client->request('GET', 'http://localhost/rest-api/laundry_sepatu/api/pelanggan', [
            'query' => [
                'id_pelanggan' => $id_pelanggan
            ]
        ]);

        $result = json_decode($response->getBody()->getContents(), true);

        return view('detail', ['pelanggan' => $result['data']]);
    }
    public function hapus($id_pelanggan) {

        $pelanggan = DB::table('pelanggan')->where('id_pelanggan',$id_pelanggan)->delete();
        return redirect('/pelanggan');
    }

}
