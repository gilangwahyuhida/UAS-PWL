<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AboutController extends Controller
{
    public function index() {
        $data['judul'] = 'Sistem Informasi Laundry Sepatu';
        $data['pembuat'] = 'Gilang, Brian, Bahrul';
        $data['kelas'] = 'TI-2A';

            return view('about')->with('tampil', $data);
    }
}
